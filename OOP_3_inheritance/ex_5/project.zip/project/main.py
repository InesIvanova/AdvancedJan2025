from project.cat import Cat
from project.dog import Dog

cat = Cat()
dog = Dog()

print(cat.eat())
print(dog.eat())
print(cat.meow())
print(dog.bark())

print(cat.bark())